notas = []

while True:
    print("\n1 - Adicionar nota")
    print("2 - Listar notas")
    print("3 - Calcular média")
    print("4 - Mostrar notas positivas")
    print("0 - Sair")

    escolha = int(input("Qual a sua escolha: "))

    if escolha == 1:
        nota = int(input("Digite a nota: "))
        if 0 <= nota <= 20:
            notas.append(nota)
            print("Nota adicionada com sucesso.")
        else:
            print("Nota inválida.")

    elif escolha == 2:
        print("Lista de notas:")
        for n in notas:
            print(n)

    elif escolha == 3:
        if len(notas) > 0:
            media = sum(notas) / len(notas)
            print(f"Média das notas: {media:.2f}")
        else:
            print("Ainda não existem notas.")

    elif escolha == 4:
        print("Notas positivas:")
        for n in notas:
            if n >= 10:
                print(n)

    elif escolha == 0:
        print("Programa terminado.")
        break

    else:
        print("Opção inválida.")