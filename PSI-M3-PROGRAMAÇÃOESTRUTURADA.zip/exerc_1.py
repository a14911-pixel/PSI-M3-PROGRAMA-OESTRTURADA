print("Afonso")
print("GPSI")
print("OFICINA")