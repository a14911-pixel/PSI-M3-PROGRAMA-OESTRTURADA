c = float(input("Insira a temperatura:"))
c = int(c)
print(f"o valor é {c}")

c = float(input("Insira a temperatura:"))
f = (c * 9/5) + 32
print("Fahrenheit:" , f)

