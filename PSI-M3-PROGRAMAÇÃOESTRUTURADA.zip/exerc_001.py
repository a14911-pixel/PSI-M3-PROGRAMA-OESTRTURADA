#exerc_001

nota = float(input("Indique a nota:"))

print(nota >= 10)

