idade = 16
print(type(idade))

opA = input("Indique o primeiro valor:")
opB = input("Indique o segundo valor:")

soma = int(opA) + int(opB)

print(f"O resultado da soma entre {opA} e {opB} é {soma}")

c = float(input("Insira a temperatura:"))
c = int(c)
print(f"o valor é: {c}")
