valor = int(input("Indique um valor:"))
print(valor % 2)