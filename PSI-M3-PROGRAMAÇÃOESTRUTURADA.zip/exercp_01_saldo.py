saldo = 100
valor_a_levantar = int(input("Insere o valor a levantar:"))
saldo_restante = saldo - valor_a_levantar




if valor_a_levantar <= saldo:
   print(f"Levantou {valor_a_levantar} euros. ")
   print(f"Você ainda tem {saldo_restante} euros na conta")
else:
   print("Não consegues levantar esse valor.")
   print(f"Ficarias com {saldo_restante} euros.")




   

