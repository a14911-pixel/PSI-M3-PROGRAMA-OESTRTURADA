num_1 = int(input("Insira o primeiro número: "))
num_2 = int (input("Insira o segundo o número:"))
num_3 = int (input("Insira o terceiro o número:"))

if num_1 >= num_2 and num_1 >= num_3:
   print(f"O {num_1} é o maior")
elif num_2 >= num_1 and num_2 >= num_3:
   print(f"O {num_2} é o maior")
elif num_1 == num_2 == num_3:
   print(f"Igual")
else:
   print(f"O maior numero é {num_3}")

   

