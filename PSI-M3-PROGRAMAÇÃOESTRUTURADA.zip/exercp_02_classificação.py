idade = int(input("Insira a sua idade:"))

if idade < 13:
   print("És uma criança.")

elif idade <= 17:
   print("És jovem.")

elif idade <= 64:
   print("És adulto.")
 
elif idade <= 65:
   print("És sénior")


