nome = input("Qual o seu nome:")
ano_nascimento = input("Qual o seu ano de nascimento:")
idade_aproximada = 2026 - int(ano_nascimento)

print(f"Olá, {nome}, tens aproximadamente {idade_aproximada} anos em 2026")