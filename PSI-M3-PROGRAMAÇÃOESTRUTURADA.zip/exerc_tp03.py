primeiro_valor = float(input("Indique o primeiro valor:"))
segundo_valor = float(input("Indique o segundo valor:"))

soma = (primeiro_valor) + (segundo_valor)
subtracao = (primeiro_valor) - (segundo_valor)
Multiplicacao = (primeiro_valor) * (segundo_valor)
Divisao = (primeiro_valor) / (segundo_valor)

print(f"O resultado da soma entre {primeiro_valor} e {segundo_valor} é {soma}")

print(f"O resultado da subtração entre {primeiro_valor} e {segundo_valor} é {subtracao}")
print(f"O resultado da multiplicação entre {primeiro_valor} e {segundo_valor} é {Multiplicacao}")
print(f"O resultado da divisão entre {primeiro_valor} e {segundo_valor} é {Divisao}")
