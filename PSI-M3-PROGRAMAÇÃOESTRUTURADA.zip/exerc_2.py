nome = "Afonso"
idade = 15

print("nome:", nome)
print("idade:", idade)
print("Ola, meu nome é", nome, "e tenho", idade, "anos.")




