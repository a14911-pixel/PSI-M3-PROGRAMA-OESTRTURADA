user = str(input("Insire o username:"))
password = float(input("Insire a password:"))

username_correto = ("admin")
password_correta = 1234

print(user == username_correto and password == password_correta)