# Exercício B1 - Contagem Simples (while) 

contagem = 1
while contagem < 10:
    print(contagem)
    contagem += 1

# Exercício B2 - Contagem Decrescente (while)
contagem = 10
while contagem > 0:
    print(contagem)
    contagem -= 1


# Exercício B3 - Contagem com for
for i in range(1,21):
   print(i)

# Exercício B4 - Números Pares
for i in range (0,21,2):
   print(i)

# Exercício I1 - Soma de 1 a 100


soma = 0
for i in range(1,101):
   soma += i
   print(f"A Somar {i} Soma atual: {soma}")

print(f"Resultado final: {soma}")

# Exercício I2 - Tabuada

num = int(input("Insira um numero: "))
while num > 0:
    print(num)
    num = int(input("Insira um numero: "))
else:
    print(f"O programa foi interrompido")

# Exercício I3 - Contador de Pares
i = 0
for numero in range(0,51,2):
   print(numero)
   i += 1

print(f"Existem {i} numeros pares de 1 a 50")

# Exercício A1 - Soma Personalizada
soma = 0
nums = int(input("Quantos numeros queres inserir:"))
for i in range(nums):
   numero = float(input("Insira esses numeros:"))
   soma += numero
print(f"A soma total desses numeros é {soma}")

# Exercício A2 - Menu Repetitivo
print("1 – Mostrar números de 1 a 10")
print("2 – Mostrar números pares até 20")
print("0 – Sair")

opcao = int(input("Escolha uma opção:"))

if opcao == 1:
    print("Mostrar numeros de 1 a 10")
    print("Escolha outra opção")
elif opcao == 2:
    print("Mostrar numeros pares até 20")
    print("Escolha outra opção")
elif opcao == 0:
    print("Sair")
else:
    print("Opção inválida! Tente outra vez")

# Exercício A3 - Fatorial
i = int(input("Insira um numero:"))
fatorial = 1
for i in range(1, i + 1):
   fatorial *= i

print(f"O fatorial de {i} é {fatorial}")



